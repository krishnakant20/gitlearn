function secondFunction(){
    console.log("Second function invoked!");
    alert("Rewriting the entire HTML!");
    document.write("Add the content");
}