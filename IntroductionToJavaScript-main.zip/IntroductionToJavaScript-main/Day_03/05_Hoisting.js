// Variable Hoisting...

function hositingTest(){
    console.log(number);
    var number;
    number = 10;
}
hositingTest();