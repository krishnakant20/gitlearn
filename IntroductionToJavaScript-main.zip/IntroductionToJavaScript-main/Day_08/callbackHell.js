let verifyUser = (username, password, callback) => {
  if (error) {
    callback(error);
  } else {
    getRoles = (username, callback) => {
      if (error) {
        callback(error);
      } else {
        logUserAccess = (username, callback) => {
          callback();
        };
      }
    };
  }
};
