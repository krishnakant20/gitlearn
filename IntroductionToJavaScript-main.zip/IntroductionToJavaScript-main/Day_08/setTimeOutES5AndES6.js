function callBack() {
	console.log("Welcome to upGrad");
}
setTimeout(callBack, 5000);



setTimeout(() => {
    console.log("Welcome to upGrad");
}, 5000);