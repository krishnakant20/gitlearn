export function sum(...arr){
  return arr.reduce((accumulator, currentValue) => accumulator + currentValue);
}; 