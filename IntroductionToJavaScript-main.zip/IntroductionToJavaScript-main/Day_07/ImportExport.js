import sum from './utility.js';
console.log(sum(1, 2, 3, 4)); 